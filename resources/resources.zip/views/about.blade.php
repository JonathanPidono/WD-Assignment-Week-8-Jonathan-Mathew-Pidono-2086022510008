@extends('layouts.app')

@section('title', 'Home')

@section('content')
    <div class="max-w-5xl mx-auto px-6 py-12">
        <section class="mb-12">
            <h1 class="text-4xl font-semibold mb-4">Hi, I'm Jona.</h1>
            <p class="text-lg text-slate-700 max-w-2xl mb-6">
                Informatics student at Ciputra University Makassar. I build mobile apps with Flutter
                and websites with Laravel.
            </p>
            <div class="flex flex-wrap gap-4">
                <a href="/about"
                   class="px-4 py-2.5 text-sm font-medium bg-slate-900 text-white hover:bg-slate-700">
                    About me
                </a>
                <a href="/contact"
                   class="px-4 py-2.5 text-sm font-medium border border-slate-900 text-slate-900 hover:bg-slate-100">
                    Contact me
                </a>
            </div>
        </section>

        <section>
            <h2 class="text-xl font-semibold mb-4">Latest projects</h2>
            <ul class="border-t border-slate-300">
                <li class="py-4 border-b border-slate-300">
                    <h3 class="font-medium">PureMarine</h3>
                    <p class="text-slate-700">
                        An interactive web-based learning platform about ocean pollution in Indonesia.
                    </p>
                </li>
                <li class="py-4 border-b border-slate-300">
                    <h3 class="font-medium">TCG Vault</h3>
                    <p class="text-slate-700">
                        A Flutter app for tracking and managing a card collection.
                    </p>
                </li>
            </ul>
        </section>

        <section class="mt-12">
            <div class="flex flex-wrap items-baseline justify-between gap-4 mb-4">
                <h2 class="text-xl font-semibold">Latest posts</h2>
                <a href="/blog" class="text-sm underline underline-offset-4 text-slate-700 hover:text-slate-900">View all posts</a>
            </div>
            <ul class="border-t border-slate-300">
                <li class="border-b border-slate-300">
                    <a href="https://github.com/JonathanPidono/JonathanPidono.github.io.git" class="block py-4 group">
                        <h3 class="font-medium group-hover:underline underline-offset-4">Calculus Journal</h3>
                        <p class="text-slate-700">A journal of my calculus course material, written to review and understand each topic.</p>
                    </a>
                </li>
                <li class="border-b border-slate-300">
                    <a href="https://laravel.com/framework/docs/12.x/installation" class="block py-4 group">
                        <h3 class="font-medium group-hover:underline underline-offset-4">Learning Laravel</h3>
                        <p class="text-slate-700">Official Laravel documentation: routing, Blade, forms, validation, and more.</p>
                    </a>
                </li>
                <li class="border-b border-slate-300">
                    <a href="https://docs.flutter.dev/" class="block py-4 group">
                        <h3 class="font-medium group-hover:underline underline-offset-4">Learning Flutter</h3>
                        <p class="text-slate-700">Official Flutter documentation: widgets, layouts, state management, and building apps.</p>
                    </a>
                </li>
            </ul>
        </section>
    </div>
@endsection