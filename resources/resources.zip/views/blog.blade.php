@extends('layouts.app')

@section('title', 'Blog')

@section('content')
<section class="mt-6 px-4 md:px-8">
   <div class="max-w-2xl mx-auto">
      <div class="mb-4">
         <h2 class="text-3xl font-bold mb-6 text-slate-900 md:text-4xl">Latest Blog Posts</h2>
         <p class="text-base text-slate-600 leading-relaxed">Notes and documentation from what I am learning,
            including calculus, Laravel, and Flutter.</p>
      </div>

      <div class="grid divide-y divide-slate-300">

         <article class="overflow-hidden py-8">
            <span class="text-sm block text-slate-500 mb-3">19 September 2026</span>
            <h3 class="text-lg font-semibold mb-4 text-slate-900">Calculus Journal</h3>
            <div class="space-y-4 text-base text-slate-600 leading-relaxed">
               <p>This journal is where I write down what I learn in my calculus course. Instead of only
                  copying notes from class, I try to explain each topic in my own words, because I understand
                  a concept better when I have to write it out step by step.</p>
               <p>Each entry covers one topic: the main idea, a worked example, and the mistakes I made along
                  the way. Going back to these entries makes it easier to review before a quiz or an exam.</p>
            </div>
            <div class="flex flex-wrap items-center justify-between gap-4 mt-6">
               <p class="text-sm text-slate-500">By Jonathan Mathew Pidono</p>
               <a href="https://github.com/JonathanPidono/JonathanPidono.github.io.git"
                  class="text-sm font-medium underline underline-offset-4 text-slate-900 hover:text-blue-700">
                  Read my calculus journal</a>
            </div>
         </article>

         <article class="overflow-hidden py-8">
            <span class="text-sm block text-slate-500 mb-3">12 October 2026</span>
            <h3 class="text-lg font-semibold mb-4 text-slate-900">Learning Laravel</h3>
            <div class="space-y-4 text-base text-slate-600 leading-relaxed">
               <p>Laravel is the PHP framework I use to build this website. I started with the basics: routes
                  that connect a URL to a page, Blade views that turn data into HTML, and forms that send data
                  back to the server.</p>
               <p>The official documentation is the reference I keep open while I work. It explains routing,
                  Blade, validation, and many other topics with short examples, and it is where I look first
                  when I run into an error.</p>
            </div>
            <div class="flex flex-wrap items-center justify-between gap-4 mt-6">
               <p class="text-sm text-slate-500">By Jonathan Mathew Pidono</p>
               <a href="https://laravel.com/framework/docs/12.x/installation"
                  class="text-sm font-medium underline underline-offset-4 text-slate-900 hover:text-blue-700">
                  Read the Laravel documentation</a>
            </div>
         </article>

         <article class="overflow-hidden py-8">
            <span class="text-sm block text-slate-500 mb-3">15 October 2026</span>
            <h3 class="text-lg font-semibold mb-4 text-slate-900">Learning Flutter</h3>
            <div class="space-y-4 text-base text-slate-600 leading-relaxed">
               <p>Flutter is the toolkit I use to build mobile apps from a single codebase. Through my
                  coursework I have practiced building screens out of widgets, making layouts that adapt to
                  different screen sizes, and managing state.</p>
               <p>The official Flutter documentation is where I learn new widgets and see how they are meant
                  to be used. It includes guides, short videos, and a cookbook of common tasks, which makes it
                  easy to try something small before putting it into a real project.</p>
            </div>
            <div class="flex flex-wrap items-center justify-between gap-4 mt-6">
               <p class="text-sm text-slate-500">By Jonathan Mathew Pidono</p>
               <a href="https://docs.flutter.dev/"
                  class="text-sm font-medium underline underline-offset-4 text-slate-900 hover:text-blue-700">
                  Read the Flutter documentation</a>
            </div>
         </article>

      </div>
   </div>
</section>
@endsection